function Adds(){
    return <h1></h1>
}
export default Adds;