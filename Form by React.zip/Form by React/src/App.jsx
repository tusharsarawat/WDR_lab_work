import React, { useState } from "react";

import UserForm from "./UserForm";

import UserDisplay from "./UserDisplay";

function App() {
  const [user, setUser] = useState({
    username: "",

    standard: "",

    age: "",

    email: "",

    city: "",
  });

  return (
    <div>
      <UserForm onFormUpdate={setUser} />

      <UserDisplay user={user} />
    </div>
  );
}

export default App;
