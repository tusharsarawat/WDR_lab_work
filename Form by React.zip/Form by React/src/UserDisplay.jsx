import React from 'react';

function UserDisplay({ user }) {
    return (
        <div>
            <h2>User Data</h2>
            <p>Name: {user.username}</p>
            <p>Standard: {user.standard}</p>
            <p>Age: {user.age}</p>
            <p>Email: {user.email}</p>
            <p>City: {user.city}</p>
        </div>
    );
}

export default UserDisplay;